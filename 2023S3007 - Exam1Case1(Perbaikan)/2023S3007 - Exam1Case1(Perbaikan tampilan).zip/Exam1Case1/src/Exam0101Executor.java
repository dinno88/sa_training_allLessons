import java.util.Scanner;

public class Exam0101Executor {
    public static void main(String[] args) {
        Exam0101Controller controller = new Exam0101Controller();
        controller.readData();
        controller.sortingData();
        controller.showData();
    }
}