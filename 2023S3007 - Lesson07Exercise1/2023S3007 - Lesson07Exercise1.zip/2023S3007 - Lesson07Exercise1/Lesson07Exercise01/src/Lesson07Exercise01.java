import java.util.Scanner;

public class Lesson07Exercise01{
	public static void main(String[] args) {
		StudentRegistration registration = new StudentRegistration();
		registration.readData();
		registration.sortingData();
		registration.showData();
	}
}